<?php
$age = 20;
if (($age >= 18) && ($age <=35)){
    print("Счастливчик");
}
else if (($age >= 1) && ($age <=17)){
    print("Слишком молод");
}
else {
    print("На повезло");
}

?>