<?php
$a = 10;
$b = 5;
$c = $a*$b;


print('a = '.$a."<br>");
print('b = '.$b."<br>");
print('c = '.$c."<br>");

?>