<?php
$a_str = "КОТИКИ";
$b_str = "МИЛЫЕ";
$c_str = $a_str." ".$b_str;


print('Строка a = '.$a_str."<br>");
print('Строка b = '.$b_str."<br>");
print('Результат = '.$c_str."<br>");

?>