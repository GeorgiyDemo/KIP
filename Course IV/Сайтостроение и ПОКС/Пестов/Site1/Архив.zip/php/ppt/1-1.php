<?php
$val1 = 43346;
$val2 = 5.325945;
$val3 = "Строка обыкновенная";
$val4 = true;
$val5 = null;

print('val1 = '.$val1." (".gettype($val1)).")<br>";
print('val2 = '.$val2." (".gettype($val2)).")<br>";
print('val3 = '.$val3." (".gettype($val3)).")<br>";
print('val4 = '.$val4." (".gettype($val4)).")<br>";
print('val5 = '.$val5." (".gettype($val5)).")<br>";

?>