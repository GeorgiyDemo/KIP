<!DOCTYPE html>

<html>
    
   <head>
        <meta charset="UTF-8">
        <title>Анкета</title>
    </head>  
    
    <body>
        <h1>Регистрация алкаша</h1>
        <form name="anketa" action="ank_act.php" method="POST">
            <input type="text" name="ank_name" placeholder="Имя" ><br/>
            
            <input type="submit" name="ank_submit" value="Сохранить"><br/>
  
        </form>
        
      
        
     </body>

</html>

