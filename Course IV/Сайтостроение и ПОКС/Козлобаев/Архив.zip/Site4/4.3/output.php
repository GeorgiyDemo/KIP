<?php echo htmlspecialchars($_POST['name']); ?>
<?php echo htmlspecialchars($_POST['age']); ?>
