Private Sub ClientBDButton_Click()
    Unload Me
    ClientBDForm.Show
End Sub

Private Sub CommandButton3_Click()
    Unload Me
    GetGoodsBDForm.Show
End Sub

Private Sub CommandButton4_Click()
    Unload Me
    GetManagerBDForm.Show
End Sub

Private Sub CommandButton6_Click()
    Unload Me
    GoodsSaleBDForm.Show
End Sub

Private Sub ExitButton_Click()
    Unload Me
    MainForm.Show
End Sub

Private Sub SaleManagerBDButton_Click()
    Unload Me
    SaleManagerBDForm.Show
End Sub

